📁 **Font Folder**

Fonts to be included in your CSS Files or for default templates if necessary.

You can find much more information for development and use of modules in our documentation. You can find the documentation in the repositories _docs folder.

Happy coding and have a great one!  
🐟 Bugfish <3
