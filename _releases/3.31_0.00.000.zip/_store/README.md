📁 **Store Deployment/Cache and Template**

This folder will store following files:  
- Cache Files for Downloaded Store Modules
- Downloaded Store Module Templates
- Deployed  Store Files
	+ App Files
	+ Hub Files
	+ Core Releases
	+ Module Releases
	+ Software Releases

Backend will created required folder structure upon first initialization.

You can find much more information for development and use of modules in our documentation. You can find the documentation in the repositories _docs folder.

Happy coding and have a great one!  
🐟 Bugfish <3
