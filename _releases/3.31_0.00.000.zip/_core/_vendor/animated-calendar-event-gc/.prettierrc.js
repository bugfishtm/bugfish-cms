module.exports = {
    arrowParens: "always",
    bracketLine: false,
    bracketSpacing: true,
    printWidth: 120,
    proseWrap: "preserve",
    quoteProps: "as-needed",
    semi: true,
    singleQuote: false,
    tabWidth: 2,
    trailingComma: "es5",
    useTabs: false,
};
