# Source Directory

Welcome to the Root Directory of your website! This folder contains the complete website code that should be uploaded to your web server to make your website operational.

Upon deploying this website code to your web server, MySQL tables will be installed automatically. These tables are essential for storing and managing dynamic data required by your website, such as user information, content, and settings.

Developers are advised to visit our documentation at https://bugfishtm.github.io/bugfish-cms

Happy coding! 🚀