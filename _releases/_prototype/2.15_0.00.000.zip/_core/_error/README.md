# Error Pages

**DO NOT MODIFY FILES WITHIN THIS FOLDER, AS THEY MAY BE OVERWRITTEN DURING CORE UPDATES!**

This folders does include default error pages used by htaccess files and other website functionalities. You can include them if you need to.

Happy Erroring!  
Bugfish <3