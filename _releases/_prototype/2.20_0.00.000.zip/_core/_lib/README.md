📁 **Library Folder**

In this folders you can find function libraries of this cms!

**Note:** Changes in this folder are NOT persistent and will be overwritten by core updates.

Happy coding and have a great one!  
🐟 Bugfish <3