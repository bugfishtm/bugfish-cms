📁 **Vendor Library Folder**

The Third-Party Libraries directory is dedicated to storing third-party libraries utilized in the project. You can look up the different folders to find more informations about the included 3rd party project and theire licenses, which are also documented in our documentation!

**Note:** Changes in this folder are NOT persistent and will be overwritten by core updates.

Happy coding and have a great one!  
🐟 Bugfish <3