📁 **Error Pages Folder**

This folders does include default error pages used by htaccess files and other website functionalities. You can include them if you need to.

**Note:** Changes in this folder are NOT persistent and will be overwritten by core updates.

Happy coding and have a great one!  
🐟 Bugfish <3