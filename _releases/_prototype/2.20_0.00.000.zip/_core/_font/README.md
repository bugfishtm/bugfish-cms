📁 **Font Library Folder**

In this folder you find integrated fonts which are delivered with this CMS for you to  be used. Just include them in your CSS File and choose them as font family on your website if necessary! Look up the licenses in the different folders our at our documentation if required.

**Note:** Changes in this folder are NOT persistent and will be overwritten by core updates.

Happy coding and have a great one!  
🐟 Bugfish <3