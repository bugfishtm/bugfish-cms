# Additional Website Files and Cache

**DO NOT MODIFY FILES WITHIN THIS FOLDER, AS THEY MAY BE OVERWRITTEN DURING CORE UPDATES!**

The Additional Website Files and Cache directory stores files essential for core API requests and actions, such as switching to the admin panel/frontend and saving JavaScript errors in the database.