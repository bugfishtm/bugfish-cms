# MySQL Files

**DO NOT MODIFY FILES WITHIN THIS FOLDER, AS THEY MAY BE OVERWRITTEN DURING CORE UPDATES!**

This folder does contain MySQL Files to be auto installed by the CMS Runtime. Do not change code here or upload your own mysql databases. Do that in your site module!