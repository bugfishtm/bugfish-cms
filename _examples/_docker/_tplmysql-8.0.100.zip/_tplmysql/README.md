# Docker Module Template for CMS

## Overview
This module provides a template for deploying Docker Compose files directly from within your CMS. It simplifies the process of container orchestration by offering an easy-to-use interface for setting up and managing Dockerized applications. With this module, you can customize Docker Compose configurations, making deployment quick and efficient.

## Features
- **Pre-configured Docker Compose**: A ready-to-use `docker-compose.yml` file that can be easily customized via the CMS admin interface.
- **Dynamic Substitutions**: Simplify deployment by using placeholders in the Docker Compose file that can be configured through the CMS admin interface. Each substitution key is followed by a description for easy understanding.
- **Version Tracking**: Version information is provided for easy updates and maintenance.
- **Changelog**: Track changes and updates made to the module over time.
- **Security**: An `index.php` file is included to prevent directory listing and unauthorized access.
- **Visual Preview**: A `preview.jpg` image is included to provide a visual overview of the module in the CMS store.

## File Structure
- **version.php**: Contains version information of the module.
- **preview.jpg**: A preview image displayed in the CMS store or module overview.
- **changelog.php**: A changelog file that tracks all updates and changes made to the module.
- **index.php**: A file that prevents directory listing and secures the module directory.
- **docker-compose.yml**: The Docker Compose file that defines the services, networks, and volumes for your Docker environment. This file includes dynamic substitutions, which can be configured via the CMS admin interface. Each substitution key must be followed by a description explaining its purpose.

### Example of Dynamic Substitution in `docker-compose.yml`
```yaml
ports:
  - <<!!Exposed_Port:The exposed port to be used for MySQL remote connections.!!>>:3306
```
In the example above, the `<<!!Exposed_Port:The exposed port to be used for MySQL remote connections.!!>>` placeholder is dynamically set in the CMS interface. The description following the key provides clarity on its purpose, making it easier for users to configure the necessary settings. Exposed_Port is the key, following after : is the keys description for the administrator interface.
