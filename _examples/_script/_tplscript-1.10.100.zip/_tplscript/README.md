**📦 Script Module Example**

**General Information**

Script modules in bugfishCMS serve as hardlinkable full HTML pages or restricted code injections independent of any site module. These modules do not include auto-load functionalities like installing MySQL tables.

### 📁 Important Files
- `public.php`: Public full HTML files for viewing via iframe or hardlinking (optional).
- `restricted.php`: Restricted script file for injections in necessary areas (optional).
- `version.php`: Contains versioning information of the module.
- `changelog.php`: Document the module's changelog.
- `preview.jpg`: Preview image for the Administrator Module and Store.

## 🏷️ Naming Conventions
- Script module names (`RNAME`) must start with "scr" and should not exceed 10 characters.

Happy Coding!  
Bugfish