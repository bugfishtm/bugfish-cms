# Administrator Interface Files Folder

This folder holds settings file for the administrator interface to easily setup configuration of a site module in the administrator interface.
This functionality is more detailed in administrator module.

**Site Module Info**
|Variable|Description|
|-----|-----|
|$object["hive_mode_config"]["info"]|Array Information from current Site Modules version.php File|
|$object["hive_mode_config"]["path"]|Full Folder Path to current used Site Module Cronjob|
|$object["hive_mode_config"]["name"]|Site Module Current Folder Name in _site|
|$object["hive_mode_config"]["prefix"]| Current Site Module Table Prefix|
|$object["hive_mode_config"]["cookie"]| Current Site Module Cookie Prefix|

**Site Module Extension Info**  
If the executed cronjob is an extension of a site module you will have following additional data.

|Variable|Description|
|-----|-----|
|$object["extension"]["info"]| Current Extension version.php Array |
|$object["extension"]["path"]| Current Extension Folder Path |
|$object["extension"]["name"]| Current Extension Name |
|$object["extension"]["prefix"]| Current Extension Table Prefix |
|$object["extension"]["cookie"]| Current Extension Cookie Prefix |

Happy Coding!  
Bugfish <3 