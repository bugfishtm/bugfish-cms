# Javascript Loadup Folder

## Overview
The `_js` folder is designated for storing JavaScript files that are automatically loaded into the BugfishCMS via the HTML include at `/core/javascript.php`. This folder helps manage JavaScript code required for various functionalities depending on the user's login status.

## Auto-Loading Scripts
JavaScript files in this folder are auto-loaded based on specific naming conventions:

- **`js.global.*`**: These files are included for both logged-in and non-logged-in users.
- **`js.restricted.*`**: These files are included only when the user is logged in.
- **`js.public.*`**: These files are included only when the user is not logged in.


## Available Variables
Variables initialized from Site Module are available, also if this js file is an extrension for this site module you will get the following info:

|Variable|Description|
|-----|-----|
|$object["extension"]["info"]| Current Extension version.php Array |
|$object["extension"]["path"]| Current Extension Folder Path |
|$object["extension"]["name"]| Current Extension Name |
|$object["extension"]["prefix"]| Current Extension Table Prefix |
|$object["extension"]["cookie"]| Current Extension Cookie Prefix |

Happy Coding!  
Bugfish <3