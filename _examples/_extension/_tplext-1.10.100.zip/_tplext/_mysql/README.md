# Mysql Table Installation Files

## Overview
The `_mysql` folder is used for managing database tables within BugfishCMS. It contains PHP files that automate the creation of database tables if they do not already exist. This feature helps streamline the setup and maintenance of the CMS database structure.

## ⚙Auto-Execution of SQL Files
Files in this folder follow a specific naming convention: `mysql.*.php`. These files are responsible for defining database tables. If a table named like the file (without the `mysql.` prefix) does not exist in the database, the corresponding PHP file will automatically execute to create it.

## Folder Contents
The `_mysql` folder typically includes:
- **PHP Files**: Named `mysql.*.php`, each corresponding to a database table definition.

## Prefix
For Site Modules use constant prefix: \_HIVE_SITE_PREFIX_  
For Extensions use Extensions Site Module Prefix: $object["extension"]["prefix"]

Happy Coding!  
Bugfish <3