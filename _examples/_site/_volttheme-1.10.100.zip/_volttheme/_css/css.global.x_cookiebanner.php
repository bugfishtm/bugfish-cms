
/******************************************************* Cookiebanner Style  *********/
	.x_cookieBanner { -webkit-transform: translate3d(0, 0, 0); transform: translate3d(0, 0, 0); -webkit-box-sizing: border-box; -moz-box-sizing: border-box; 
		box-sizing: border-box; background-color: rgba(255, 20, 20, 0.95); color: #ccc; line-height: 26px; 
		font-family: Arial; display: block; position: fixed;font-size: 16px; bottom: 10vh; right: 0; color: #ffffff; 
		width: 200px; border-top-left-radius: 10px; border-bottom-left-radius: 10px; padding: 20px;
		z-index: 600; }
	.x_cookieBanner a { color: #000000; text-decoration: none; font-weight: bold; }
	.x_cookieBanner a:hover { color: #ffffff; }	
	.x_cookieBanner input.x_cookieBanner_close { background-color: #1b1b1b; color: #fff; display: inline-block; border: none !important; width: 100% !important; border-color: #fff !important; 
		border-radius: 10px !important; cursor: pointer; height: 40px !important; font-size: 13px !important; font-family: Arial !important; font-weight: 700 !important; padding-top: 5px; padding-bottom: 5px; }
	.x_cookieBanner input.x_cookieBanner_close:hover { background-color: #121212; }
	
	