<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
		
		File Description:
			Loadup File for this Site Module!
	*/ if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } 
	if(!_HIVE_ADMIN_SITE_ OR _HIVE_ADMIN_SITE_ == _HIVE_MODE_) { Header("Location: ./_site/"._HIVE_MODE_."/index.html"); }
	?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
	<link rel="icon" href="./_site/<?php echo _HIVE_MODE_; ?>/favicon.ico" type="image/x-icon">
    <title><?php echo $object["hive_mode"]["name"]; ?></title>
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        #top-bar {
            background-color: #333;
            padding: 10px;
            text-align: center;
            color: #fff;
        }

        #iframe-container {
            width: 100%;
            height: calc(100vh - 40px); /* Adjusted for the top bar height */
			border-bottom: 0px;
			margin-bottom: 0px;
			padding-bottom: 0px;
        }

        #myIframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>
<body>
    <div id="top-bar">
        <a href="./_site/<?php echo _HIVE_MODE_; ?>/index.html" target="_blank" style="color: #fff; text-decoration: none;">[Direct Link]</a> - 
        <a href="./_core/_action/admin_switch.php" style="color: #fff; text-decoration: none;">[Back to Backend]</a>
    </div>
    
    <div id="iframe-container">
        <iframe id="myIframe" src="./_site/<?php echo _HIVE_MODE_; ?>/index.html" frameborder="0"></iframe>
    </div>
</body>
</html>
