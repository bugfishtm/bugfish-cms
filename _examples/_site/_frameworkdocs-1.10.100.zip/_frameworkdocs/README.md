📖 **Documentation**

This folder contains project documentation that can be opened with any web browser. Explore and discover essential information to understand and utilize the project effectively.

Happy coding and have a great one!  
🐟 Bugfish <3