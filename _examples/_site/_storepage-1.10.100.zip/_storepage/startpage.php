<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } ?>	
            <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">bugfishCMS</h1>
                    </div>
                </div>
            </div>  
            <div class="row mb-0">
                <div class="col-12 col-xl-12">	
					<div class="col-12 mb-4">
						<div class="row mb-4">
							<div class="col-12 col-sm-16 col-xl-16 mb-0">
								<div class="card border-0 shadow">
								<div class="card-header">
									<div class="row align-items-center">
										<div class="col">
											<h2 class="fs-5 fw-bold mb-0">Introduction</h2>
											<small>What is this page about?!</small>
										</div>
									</div>
								</div>	
									<div class="card-body pb-0">
										<div class="row d-block d-xl-flex align-items-center">
											<p>bugfishCMS is a powerful and versatile content management system designed to empower both end-users and developers alike. Whether you're a business owner looking to streamline your online presence or a developer seeking robust backend functionalities, bugfishCMS has you covered.</p>

<p>With bugfishCMS, you can effortlessly manage user permissions, debug your websites for optimal performance, and customize the administrator interface to suit your preferences. Enjoy multi-language support, dynamic color schemes, and a simplified installation process with our intuitive GUI installer.</p>

<p>For developers, bugfishCMS offers a comprehensive suite of backend features, including multi-site management, framework integration, debugging tools, and dynamic code loading capabilities. Seamlessly integrate with our Bugfish Framework and leverage ready-to-use updater routines for effortless project maintenance.</p>

<p>Explore our extension store for additional functionalities, manage files and media assets with ease, and harness integrated CRM tools.</p>

										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>			
				<?php
				$features1 = [
					"Administrator Module" => "Comprehensive, responsive administration backend featuring file management, user management, debugging insights, and access to the extension store. Centralizes all administrative functions, providing a user-friendly and powerful control panel.",
					"User and Group Manager" => "Organize users into distinct groups for streamlined access control and collaboration. Link different features and functions to groups, giving you great control over your user base. Essential for managing user permissions and access levels, ensuring that only authorized users can access sensitive information.",	
					"Installer" => "Simplified installation process with a graphical user interface (GUI). Reduces the technical barrier for end-users.",		
					"Updater" => "Easy-to-use updater with a graphical user interface (GUI) for seamless updates. Simplifies the maintenance of the CMS.",
					"File Management" => "Robust file management capabilities for uploading, organizing, and managing files and media assets. Ensures efficient organization and retrieval of media and document files, crucial for content-heavy websites.",
					"Extension and Dedicated Store" => "Centralized marketplace for discovering, installing, and managing extensions, including setting up a dedicated extension store for customization and monetization. Empowers users to enhance their CMS with additional functionalities tailored to their needs.",
					"Store System and Module Downloads" => "Fully functional store system for accessing and downloading site modules, enhancing website customization.",
					"Notification System" => "System notifications to inform users about events and changes.",
					"Docker Control" => "Integrated control of Docker containers within the CMS. Provides advanced users with tools to manage containerized applications, enhancing scalability and deployment flexibility."
				];
				
				$features2 = [
					"Multi-Site Management" => "Effortlessly manage multiple websites from a centralized platform, ensuring efficient oversight of various online properties.",
					"Framework Integration" => "Seamlessly integrate with the Bugfish Framework for comprehensive bug tracking and debugging capabilities, including all classes and functionalities of CSS, JavaScript, and PHP Libraries.",
					"Debugging Tools" => "Access robust debugging tools to enhance backend operations, quickly identify errors, and test site performance or SQL issues with various classes.",
					"Multi-Language Support" => "Dynamically add and manage multiple languages to cater to a global audience.",
					"Dynamic Themes and Colors" => "Enable dynamic switching of website themes and adjustment of theme colors for a personalized appearance.",
					"Dynamic CSS/JS Load" => "Facilitate the dynamic loading of CSS and JavaScript files for optimized website performance.",
					"Updater Backend" => "Leverage ready-to-use updater routines per Site Module for effortless project updates.",
					"Dynamic Code Loading" => "Support the dynamic loading of code snippets or scripts.",
					"Dynamic Cronjobs" => "Schedule and execute dynamic cronjobs within the CMS to automate routine tasks.",
					"Extension Support" => "Extend different modules with custom or store-downloaded extensions.",
					"Deployment" => "Deploy your own cluster of bugfishCMS instances and control module and core update deployments via your own instances public store.",
					"Integrated Templates" => "Access a selection of pre-designed templates integrated into the CMS for simplified website design and customization.",
					"Example Modules" => "Explore a collection of example modules showcasing various functionalities and capabilities of the CMS, serving as references and inspiration for users and developers.",
					"Developer-Friendly Interface" => "Utilize a comprehensive user interface tailored for developers to access and manipulate the system through coding, enabling extensive customization and advanced functionality."
				];
				?>		
					<div class="col-12 mb-4">
						<div class="row mb-4">
							<div class="col-12 col-sm-16 col-xl-16 mb-0 ">
								<div class="card border-0 shadow">
									<div class="card-header">
										<div class="row align-items-center">
											<div class="col">
												<h2 class="fs-5 fw-bold mb-0">End-User Features</h2>
												<small>This project provides a comprehensive overview of Docker and Apache-based website hosting, enabling you to manage and deploy your websites effectively!</small>
											</div>
										</div>
									</div>	
									<div class="card-body pb-2">
										<div class="row d-block d-xl-flex align-items-center">
											<div class="table-responsive" >
												<table class="table align-items-center table-flush"  style="border-collapse: collapse; border: none;">
													<?php foreach($features1 as $key => $value) {  ?>
																<tr  style="border:none;">
																	<td class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;border:none;">
																✅ <?php echo $key; ?> <br />
																<small><?php echo $value; ?></small>
																	</td>
																</tr>
													<?php } ?>	
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
					<div class="col-12 mb-4">
						<div class="row mb-4">
							<div class="col-12 col-sm-16 col-xl-16 mb-0">
								<div class="card border-0 shadow">
									<div class="card-header">
										<div class="row align-items-center">
											<div class="col">
												<h2 class="fs-5 fw-bold mb-0">Developer Features</h2>
												<small>This project is crafted to simplify the deployment and creation of websites and complex scripts or builds. It allows you to deploy multiple websites on one domain and manage debugging information efficiently!</small>
											</div>
										</div>
									</div>	
									<div class="card-body pb-4">
										<div class="row d-block d-xl-flex align-items-center">
											<div class="table-responsive">
												<table class="table align-items-center table-flush" style="border-collapse: collapse; border: none;">
													<?php foreach($features2 as $key => $value) {  ?>
																<tr style="border:none;">
																	<td class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;border:none;">
																✅ <?php echo $key; ?> <br />
																<small><?php echo $value; ?></small>
																	</td>
																</tr>
													<?php } ?>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
                </div>
            </div>

			<?php
				$libraries = [
					[
						"Folder Name" => "adminbsb",
						"License" => "MIT",
						"Github Link" => "https://github.com/gurayyarar/AdminBSBMaterialDesign"
					],
					[
						"Folder Name" => "alpine",
						"License" => "MIT",
						"Github Link" => "https://github.com/alpinejs/alpine"
					],
					[
						"Folder Name" => "animatecss",
						"License" => "MIT",
						"Github Link" => "https://github.com/animate-css/animate.css"
					],
					[
						"Folder Name" => "animated-calendar-event-gc",
						"License" => "MIT",
						"Github Link" => "https://www.npmjs.com/package/animated-calendar-event-gc"
					],
					[
						"Folder Name" => "autosize",
						"License" => "MIT",
						"Github Link" => "https://github.com/jackmoore/autosize"
					],
					[
						"Folder Name" => "bootstrap-colorpicker",
						"License" => "MIT",
						"Github Link" => "https://github.com/itsjavi/bootstrap-colorpicker"
					],
					[
						"Folder Name" => "bootstrap-material-datetimepicker",
						"License" => "MIT",
						"Github Link" => "https://github.com/T00rk/bootstrap-material-datetimepicker"
					],
					[
						"Folder Name" => "bootstrap-notify",
						"License" => "MIT",
						"Github Link" => "https://github.com/mouse0270/bootstrap-notify"
					],
					[
						"Folder Name" => "bootstrap-select",
						"License" => "MIT",
						"Github Link" => "https://github.com/snapappointments/bootstrap-select"
					],
					[
						"Folder Name" => "bootstrap-tagsinput",
						"License" => "MIT",
						"Github Link" => "https://github.com/bootstrap-tagsinput/bootstrap-tagsinput"
					],
					[
						"Folder Name" => "bootstrap",
						"License" => "MIT",
						"Github Link" => "https://github.com/twbs/bootstrap"
					],
					[
						"Folder Name" => "boxicons",
						"License" => "CC BY 4.0",
						"Github Link" => "https://github.com/atisawd/boxicons"
					],
					[
						"Folder Name" => "bugfish-dashboard",
						"License" => "GPLv3",
						"Github Link" => "N/A"
					],
					[
						"Folder Name" => "bugfish-framework",
						"License" => "GPLv3",
						"Github Link" => "N/A"
					],
					[
						"Folder Name" => "bugfish-jquery-sortselect",
						"License" => "GPLv3",
						"Github Link" => "N/A"
					],
					[
						"Folder Name" => "bugfish-jquery-sortselect_root",
						"License" => "MIT",
						"Github Link" => "N/A"
					],
					[
						"Folder Name" => "changa",
						"License" => "SIL OFL",
						"Github Link" => "https://fonts.google.com/specimen/Changa"
					],
					[
						"Folder Name" => "chartjs",
						"License" => "MIT",
						"Github Link" => "https://github.com/chartjs/Chart.js"
					],
					[
						"Folder Name" => "chatist",
						"License" => "MIT",
						"Github Link" => "https://github.com/wachidny/chatist"
					],
					[
						"Folder Name" => "choices.js",
						"License" => "MIT",
						"Github Link" => "https://github.com/Choices-js/Choices"
					],
					[
						"Folder Name" => "chosen",
						"License" => "MIT",
						"Github Link" => "https://github.com/harvesthq/chosen"
					],
					[
						"Folder Name" => "comicneue",
						"License" => "SIL OFL",
						"Github Link" => "https://github.com/crozynski/comic-neue"
					],
					[
						"Folder Name" => "country-flags-icons",
						"License" => "MIT",
						"Github Link" => "https://github.com/lipis/flag-icons"
					],
					[
						"Folder Name" => "datatables",
						"License" => "MIT",
						"Github Link" => "https://github.com/DataTables/DataTables"
					],
					[
						"Folder Name" => "daypilot-lite",
						"License" => "AGPLv3",
						"Github Link" => "https://github.com/DHTMLX/daypilot-lite"
					],
					[
						"Folder Name" => "dropzone",
						"License" => "MIT",
						"Github Link" => "https://github.com/dropzone/dropzone"
					],
					[
						"Folder Name" => "editable-table",
						"License" => "MIT",
						"Github Link" => "https://github.com/mindmup/editable-table"
					],
					[
						"Folder Name" => "evo-event-calendar",
						"License" => "MIT",
						"Github Link" => "https://github.com/serhii-londar/evo-calendar"
					],
					[
						"Folder Name" => "flot-charts",
						"License" => "MIT",
						"Github Link" => "https://github.com/flot/flot"
					],
					[
						"Folder Name" => "focustrap",
						"License" => "MIT",
						"Github Link" => "https://github.com/focus-trap/focus-trap"
					],
					[
						"Folder Name" => "font-awesome",
						"License" => "MIT",
						"Github Link" => "https://github.com/FortAwesome/Font-Awesome"
					],
					[
						"Folder Name" => "free-file-icons",
						"License" => "CC0 1.0",
						"Github Link" => "https://github.com/naptha/icon"
					],
					[
						"Folder Name" => "githubbuttons",
						"License" => "MIT",
						"Github Link" => "https://github.com/ntkme/github-buttons"
					],
					[
						"Folder Name" => "gmaps",
						"License" => "MIT",
						"Github Link" => "https://github.com/hpneo/gmaps"
					],
					[
						"Folder Name" => "ion-rangeslider",
						"License" => "MIT",
						"Github Link" => "https://github.com/IonDen/ion.rangeSlider"
					],
					[
						"Folder Name" => "jquery-cookie",
						"License" => "MIT",
						"Github Link" => "https://github.com/carhartl/jquery-cookie"
					],
					[
						"Folder Name" => "jquery-countto",
						"License" => "MIT",
						"Github Link" => "https://github.com/mhuggins/jquery-countTo"
					],
					[
						"Folder Name" => "jquery-gantt",
						"License" => "MIT",
						"Github Link" => "https://github.com/robicch/jQueryGantt"
					],
					[
						"Folder Name" => "jquery-inputmask",
						"License" => "MIT",
						"Github Link" => "https://github.com/RobinHerbots/Inputmask"
					],
					[
						"Folder Name" => "jquery-knob",
						"License" => "MIT",
						"Github Link" => "https://github.com/aterrien/jQuery-Knob"
					],
					[
						"Folder Name" => "jquery-slimscroll",
						"License" => "MIT",
						"Github Link" => "https://github.com/rochal/jQuery-slimScroll"
					],
					[
						"Folder Name" => "jquery-sparkline",
						"License" => "MIT",
						"Github Link" => "https://github.com/gwatts/jquery.sparkline"
					],
					[
						"Folder Name" => "jquery-spinner",
						"License" => "MIT",
						"Github Link" => "https://github.com/xixilive/jquery-spinner"
					],
					[
						"Folder Name" => "jquery-steps",
						"License" => "MIT",
						"Github Link" => "https://github.com/rstaib/jquery-steps"
					],
					[
						"Folder Name" => "jquery-timeline",
						"License" => "MIT",
						"Github Link" => "https://github.com/ryanfitzgerald/jquery-timeline"
					],
					[
						"Folder Name" => "jquery-validation",
						"License" => "MIT",
						"Github Link" => "https://github.com/jquery-validation/jquery-validation"
					],
					[
						"Folder Name" => "jquery",
						"License" => "MIT",
						"Github Link" => "https://github.com/jquery/jquery"
					],
					[
						"Folder Name" => "jvectormap",
						"License" => "MIT",
						"Github Link" => "https://github.com/bjornd/jvectormap"
					],
					[
						"Folder Name" => "lato",
						"License" => "SIL OFL",
						"Github Link" => "https://fonts.google.com/specimen/Lato"
					],
					[
						"Folder Name" => "leafletjs",
						"License" => "BSD-2-Clause",
						"Github Link" => "https://github.com/Leaflet/Leaflet"
					],
					[
						"Folder Name" => "light-gallery",
						"License" => "GPL-3.0",
						"Github Link" => "https://github.com/sachinchoolur/lightgallery"
					],
					[
						"Folder Name" => "login-template",
						"License" => "MIT",
						"Github Link" => "https://github.com/gustavohenke/login-template"
					],
					[
						"Folder Name" => "magicsuggest",
						"License" => "MIT",
						"Github Link" => "https://github.com/nicolasbize/magicsuggest"
					],
					[
						"Folder Name" => "material-design-iconic-font",
						"License" => "MIT",
						"Github Link" => "https://github.com/zavoloklom/material-design-iconic-font"
					],
					[
						"Folder Name" => "materialize-css",
						"License" => "MIT",
						"Github Link" => "https://github.com/Dogfalo/materialize"
					],
					[
						"Folder Name" => "modelviewer",
						"License" => "Apache-2.0",
						"Github Link" => "https://github.com/google/model-viewer"
					],
					[
						"Folder Name" => "momentjs",
						"License" => "MIT",
						"Github Link" => "https://github.com/moment/moment"
					],
					[
						"Folder Name" => "morrisjs",
						"License" => "MIT",
						"Github Link" => "https://github.com/morrisjs/morris.js"
					],
					[
						"Folder Name" => "multi-select",
						"License" => "MIT",
						"Github Link" => "https://github.com/lou/multi-select"
					],
					[
						"Folder Name" => "multi.js",
						"License" => "MIT",
						"Github Link" => "https://github.com/WillSullivan/multi.js"
					],
					[
						"Folder Name" => "nestable",
						"License" => "MIT",
						"Github Link" => "https://github.com/dbushell/Nestable"
					],
					[
						"Folder Name" => "Nestable2",
						"License" => "MIT",
						"Github Link" => "https://github.com/RamonSmit/Nestable2"
					],
					[
						"Folder Name" => "node-waves",
						"License" => "MIT",
						"Github Link" => "https://github.com/fians/Waves"
					],
					[
						"Folder Name" => "notyf",
						"License" => "MIT",
						"Github Link" => "https://github.com/caroso1222/notyf"
					],
					[
						"Folder Name" => "nouislider",
						"License" => "MIT",
						"Github Link" => "https://github.com/leongersen/noUiSlider"
					],
					[
						"Folder Name" => "onscreen",
						"License" => "MIT",
						"Github Link" => "https://github.com/silvestreh/onScreen"
					],
					[
						"Folder Name" => "phpmailer",
						"License" => "LGPL-2.1",
						"Github Link" => "https://github.com/PHPMailer/PHPMailer"
					],
					[
						"Folder Name" => "popperjs",
						"License" => "MIT",
						"Github Link" => "https://github.com/popperjs/popper-core"
					],
					[
						"Folder Name" => "raphael",
						"License" => "MIT",
						"Github Link" => "https://github.com/DmitryBaranovskiy/raphael"
					],
					[
						"Folder Name" => "resumable",
						"License" => "MIT",
						"Github Link" => "https://github.com/23/resumable.js"
					],
					[
						"Folder Name" => "Roboto",
						"License" => "Apache-2.0",
						"Github Link" => "https://fonts.google.com/specimen/Roboto"
					],
					[
						"Folder Name" => "Salt_Regular",
						"License" => "SIL OFL",
						"Github Link" => "https://www.fontspace.com/salt-regular-font-f88036"
					],
					[
						"Folder Name" => "sass",
						"License" => "MIT",
						"Github Link" => "https://github.com/sass/sass"
					],
					[
						"Folder Name" => "select2",
						"License" => "MIT",
						"Github Link" => "https://github.com/select2/select2"
					],
					[
						"Folder Name" => "Simple-Error-Page",
						"License" => "MIT",
						"Github Link" => "https://github.com/matuzo/simple-error-page"
					],
					[
						"Folder Name" => "Simple-Mail-Template",
						"License" => "MIT",
						"Github Link" => "N/A"
					],
					[
						"Folder Name" => "simplebar",
						"License" => "MIT",
						"Github Link" => "https://github.com/Grsmto/simplebar"
					],
					[
						"Folder Name" => "smooth-scroll",
						"License" => "MIT",
						"Github Link" => "https://github.com/cferdinandi/smooth-scroll"
					],
					[
						"Folder Name" => "sortablejs",
						"License" => "MIT",
						"Github Link" => "https://github.com/SortableJS/Sortable"
					],
					[
						"Folder Name" => "spaceinvader",
						"License" => "MIT",
						"Github Link" => "https://github.com/samisaf/spaceinvader"
					],
					[
						"Folder Name" => "sweetalert",
						"License" => "MIT",
						"Github Link" => "https://github.com/t4t5/sweetalert"
					],
					[
						"Folder Name" => "sweetalert2",
						"License" => "MIT",
						"Github Link" => "https://github.com/sweetalert2/sweetalert2"
					],
					[
						"Folder Name" => "tinymce",
						"License" => "LGPL-2.1",
						"Github Link" => "https://github.com/tinymce/tinymce"
					],
					[
						"Folder Name" => "vanillajs-datepicker",
						"License" => "MIT",
						"Github Link" => "https://github.com/mymth/vanillajs-datepicker"
					],
					[
						"Folder Name" => "Volt",
						"License" => "MIT",
						"Github Link" => "https://github.com/themeselection/volt-bootstrap-5-dashboard"
					],
					[
						"Folder Name" => "waitme",
						"License" => "MIT",
						"Github Link" => "https://github.com/vadimsva/waitMe"
					],
					[
						"Folder Name" => "waypoints",
						"License" => "MIT",
						"Github Link" => "https://github.com/imakewebthings/waypoints"
					],
					[
						"Folder Name" => "you-login",
						"License" => "MIT",
						"Github Link" => "https://github.com/mohamed-aziz-you/you-login"
					],
				];
			?>	
            <div class="row mb-0">
                <div class="col-12 col-xl-12 mb-4">
				
					<div class="col-12 mb-4">
						<div class="row mb-4">
							<div class="col-12 col-sm-16 col-xl-16 mb-0">
								<div class="card border-0 shadow">
									<div class="card-header">
										<div class="row align-items-center">
											<div class="col">
												<h2 class="fs-5 fw-bold mb-0">Screenshots</h2>
												<small>Some screenshots of integrated themes.</small>
											</div>
										</div>
									</div>			
									<div class="card-body pb-0">
										<div class="row d-block d-xl-flex align-items-center">
											<div data-gallery="simple" data-loop="true" data-interval="5">
												<figure id="image-1">
													<img src="./_site/<?php echo _HIVE_MODE_; ?>/_theme/adminbsb.png" style="border-radius: 5px;">
												</figure>
												<figure id="image-2">
													<img src="./_site/<?php echo _HIVE_MODE_; ?>/_theme/windmill.png" style="border-radius: 5px;">
												</figure>
												<figure id="image-3">
													<img src="./_site/<?php echo _HIVE_MODE_; ?>/_theme/volt.png" style="border-radius: 5px;">
												</figure>
												<figure id="image-4">
													<img src="./_site/<?php echo _HIVE_MODE_; ?>/_theme/minimal.png" style="border-radius: 5px;">
												</figure>
												<nav><br />
													<small>
														<a href="#image-1" class="btn btn-primary">AdminBSB Example</a> 
														<a href="#image-2" class="btn btn-primary">Windmill Example</a> 
														<a href="#image-3" class="btn btn-primary">Volt Example</a> 
														<a href="#image-4" class="btn btn-primary">Minimal Example</a>
													</small><br /><br />
												</nav>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
				
					<div class="card border-0 shadow">
						<div class="card-header">
							<div class="row align-items-center">
								<div class="col">
									<h2 class="fs-5 fw-bold mb-0">Included Libraries</h2>
									<small>This table lists third-party scripts integrated into the CMS.</small>
								</div>
							</div>
						</div>			
						<div class="table-responsive">
							<table class="table align-items-center table-flush" style="max-width: 100%;">
								<tbody>
								<?php foreach($libraries as $key => $value) {  ?>
								<tr>
									<td class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;">
								📜 <?php echo $value["Folder Name"]; ?> <small><?php if($value["Github Link"] != "N/A") { ?> [<a href="<?php echo $value["Github Link"]; ?>" target="_blank" rel="noopener" class="text-info">Link</a>] <?php } ?> [License:<?php echo $value["License"]; ?>]</small>
									</td>
								</tr>
								<?php } 
								?>
								</tbody>
							</table>
						</div>
					</div>
                </div>
            </div>
			<script>
							/*!
				 * jQuery Simple Gallery Plugin v2.1
				 * https://github.com/straube/simple-gallery
				 *
				 * Copyright 2013, 2014 Gustavo Straube
				 */
				;(function ($) {

					'use strict';

					$.fn.gallery = function (options) {

						return this.each(function () {
							var settings = $.extend({}, $.fn.gallery.defaults, options);
							var $gallery = $(this);
							var $images  = $gallery.find(settings.tag);
							var loop;

							// Local functions
							var show = function ($image) {
								$images.removeClass('current').fadeOut().promise().done(function () {
									$image.addClass('current').fadeIn();
								});
							};

							$images.hide().first().show().addClass('current');

							$gallery.find('a').on('click', function (event) {
								var id = this.href.replace(/^[^#]*(#.*)?$/i, '$1');
								if (!id) {
									return true;
								}
								event.preventDefault();
								//window.clearInterval(loop);
								//loop = null;
								show($images.filter(id));
							});

							if (settings.loop) {
								var interval = settings.interval * 1000;
								//loop = window.setInterval(function () {
								//	var $next = $images.filter('.current').next(settings.tag);
								//	if ($next.length === 0) {
								//		$next = $images.first();
								//	}
								//	show($next);
								//}, interval);
							}
						});

					};

					$.fn.gallery.defaults = {
						tag      : 'figure',
						loop     : true,
						interval : 5
					};

					$(function () {
						var $simple = $('[data-gallery="simple"]');
						if ($simple.length) {
							$simple.gallery($simple.data());
						}
					});

				})(jQuery); 
			</script>