<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } ?>	
              <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">Download</h1>
                    </div>
                </div>
            </div>       
			<?php
				// Folder containing the files
				$folder = $object["path"].'/_store/_core/_release/';

				// Get all files in the folder
				$files = glob($folder . '*.zip');

				// Array to store version numbers
				$versions = [];

				// Function to extract version number from filename
				function extractVersion($filename) {
					preg_match('/(\d+\.\d+)/', $filename, $matches);
					return $matches[1];
				}


				// Extract version numbers from filenames
				foreach ($files as $file) {
					//$version = extractVersion(basename($file));
					$version = basename($file);
					$versions[] = $version;
				}

				// Sort the version numbers in descending order
				$versions = array_reverse($versions);
			?>	
            <div class="row mb-0">
                <div class="col-12 col-xl-4 mb-4">
					<div class="card border-0 shadow">
					<div class="card-header">
						<div class="row align-items-center">
							<div class="col">
								<h2 class="fs-5 fw-bold mb-0">Latest Release</h2>
								<small>Here you can download the latest version of bugfishCMS. It is recommended to download the full package as the Source Package only contains the source code and no example and documentation files. We will very appreciate support for this project on "<a href="https://www.patreon.com/Bugfish" rel="noopener" target="_blank">Patreon</a>"!</small>
							</div>
						</div>
					</div>
						<div class="card-header ">
							<h2 class="fs-5 fw-bold mb-1"></h2>
							<div class="d-block">
								<div class="d-flex align-items-center me-5">
									<div class="icon-shape icon-sm bg-light rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="M18.948 11.112C18.511 7.67 15.563 5 12.004 5c-2.756 0-5.15 1.611-6.243 4.15-2.148.642-3.757 2.67-3.757 4.85 0 2.757 2.243 5 5 5h1v-2h-1c-1.654 0-3-1.346-3-3 0-1.404 1.199-2.757 2.673-3.016l.581-.102.192-.558C8.153 8.273 9.898 7 12.004 7c2.757 0 5 2.243 5 5v1h1c1.103 0 2 .897 2 2s-.897 2-2 2h-2v2h2c2.206 0 4-1.794 4-4a4.008 4.008 0 0 0-3.056-3.888z"></path><path d="M13.004 14v-4h-2v4h-3l4 5 4-5z"></path></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Latest Release</label><br />
										<span class="h4 mb-0"><?php if(count($versions) > 0) { echo substr(@$versions[0] ?? '', 0, -4); } else { echo "Not available"; } ?></span>
									</div>
								</div>
							</div>
						</div>
						<div class="card-body mb-0 pb-1">
							<?php if(count($versions) > 0) { ?>   <p><a href="https://github.com/bugfishtm/bugfish-cms/archive/refs/heads/main.zip" rel="noopener" class="btn btn-info">Download Full Package</a></p> <?php } else { ?><p>There is currently no release available to download!</p>  <?php }  ?>
						</div>
					</div>
                </div>
				<script>
					// Specify the target date
					const targetDate = new Date('2012-12-21T00:00:00');

					// Function to update the countdown
					function updateCountup() {
						const currentDate = new Date();
						const timeDifference = currentDate - targetDate;

						// Calculate elapsed time
						const milliseconds = Math.abs(timeDifference);
						const seconds = Math.floor(milliseconds / 1000) % 60;
						const minutes = Math.floor(milliseconds / (1000 * 60)) % 60;
						const hours = Math.floor(milliseconds / (1000 * 60 * 60)) % 24;
						const days = Math.floor(milliseconds / (1000 * 60 * 60 * 24));

						// Display the elapsed time
						const countdownElement = document.getElementById('countup');
						countdownElement.innerHTML = `${days} days`;
					}

					// Update the countdown every second
					setInterval(updateCountup, 1000);

					// Initial call to update countdown
					updateCountup();
				</script>		
                <div class="col-12 col-xl-8">	
					<div class="col-12 mb-4">
						<div class="card border-0 shadow">
							<div class="card-header">
								<div class="row align-items-center">
									<div class="col">
										<h2 class="fs-5 fw-bold mb-0">Archived Source Packages</h2>
										<small>Here you can see and access different bugfishCMS releases. The first 3 digits represent the core release number (x.xx.), the digits after the _ sign represent the integrated administrator module release version. If the administrator release version is 0.00.000, than there is no administrator module included in the release file. These packages do only contain the source and no additional data like documentation and other! Download the full package to receive all files of this project.</small>
									</div>
								</div>
							</div>			
							<div class="table-responsive">
								<table class="table align-items-center table-flush" style="max-width: 100%;">
									<thead class="thead-light">
									<tr>
										<th class="border-bottom" scope="col">Version</th>
										<th class="border-bottom" scope="col">Download</th>
									</tr>
									</thead>
									<tbody>
									<?php $run = false; foreach($versions as $key => $value) { $run = true; ?>
									<tr>
										<th class="text-gray-900" scope="row" style="word-break: keep-all; white-space: wrap;">
											<b><?php echo $value; ?></b>
											<p style="font-size: 12px; padding-bottom: 5px;margin-bottom: 0px;"><?php if(file_exists($object["path"]."/_store/_core/_changelog/".substr($value, 0, -4).".html")) { require($object["path"]."/_store/_core/_changelog/".substr($value, 0, -4).".html"); } else { echo "Not available"; } ?></p>
										</th>
										<td class="fw-bolder text-gray-500">
										   <a href="./_store/_core/_release/<?php echo $value; ?>" class="btn btn-primary">Download Source</a>
										</td>
									</tr>
									<?php } 
									if(!$run) { 
										?>
											<tr>
												<td class="text-gray-900" scope="row" colspan="2">
													There is currently no core version available!
												</td>
											</tr>											
										
										<?php
									}
									?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
            </div>