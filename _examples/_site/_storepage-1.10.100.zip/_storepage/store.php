<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } ?>	
            <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">Store</h1>
                    </div>
                </div>
            </div>            

            <div class="row mb-0">
                <div class="col-12 col-xl-4">
					<div class="card border-0 shadow mb-4">
					<div class="card-header">
						<div class="row align-items-center">
							<div class="col">
								<h2 class="fs-5 fw-bold mb-0">Explore extensions!</h2>
								<small>Feel free to explore our ever expanding extensions! You can get more information by selecting a module out of the list below or to the right (depending on your screen size). You can also find all these modules in the official bugfishCMS Store inside the Administrator Module on your own hosted instance. We will very appreciate support for this project on "<a href="https://www.patreon.com/Bugfish" rel="noopener" target="_blank">Patreon</a>"!</small>
							</div>
						</div>
					</div>	
						<div class="card-body ">
							<div class="d-block">
								<div class="d-flex align-items-center me-5">
									<div class="icon-shape icon-sm bg-light rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="M4 13h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1zm-1 7a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v4zm10 0a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v7zm1-10h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1z"></path></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Available Extensions</label><br />
										<span class="h4 mb-0"><?php if($mods) { echo count($mods); } else { echo "Not available"; } ?></span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="card border-0 shadow mb-4">
					<div class="card-header">
						<div class="row align-items-center">
							<div class="col">
								<h2 class="fs-5 fw-bold mb-0">All for free!</h2>
								<small>This store is dedicated to non-paid software. This means you can use all the items here totally for free!</small>
							</div>
						</div>
					</div>	
						<div class="card-body ">
							<div class="d-block">
								<div class="d-flex align-items-center me-5">
									<div class="icon-shape icon-sm bg-light rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="M14 9h8v6h-8z"></path><path d="M20 3H5C3.346 3 2 4.346 2 6v12c0 1.654 1.346 3 3 3h15c1.103 0 2-.897 2-2v-2h-8c-1.103 0-2-.897-2-2V9c0-1.103.897-2 2-2h8V5c0-1.103-.897-2-2-2z"></path></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Price for all items:</label><br />
										<span class="h4 mb-0">0.00$</span>
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
				<script>
					// Specify the target date
					const targetDate = new Date('2012-12-21T00:00:00');

					// Function to update the countdown
					function updateCountup() {
						const currentDate = new Date();
						const timeDifference = currentDate - targetDate;

						// Calculate elapsed time
						const milliseconds = Math.abs(timeDifference);
						const seconds = Math.floor(milliseconds / 1000) % 60;
						const minutes = Math.floor(milliseconds / (1000 * 60)) % 60;
						const hours = Math.floor(milliseconds / (1000 * 60 * 60)) % 24;
						const days = Math.floor(milliseconds / (1000 * 60 * 60 * 24));

						// Display the elapsed time
						const countdownElement = document.getElementById('countup');
						countdownElement.innerHTML = `${days} days`;
					}

					// Update the countdown every second
					setInterval(updateCountup, 1000);

					// Initial call to update countdown
					updateCountup();
				</script>		
                <div class="col-12 col-xl-8">	
					<div class="col-12 mb-4">
					<?php
						// Folder containing the files
						$last = false;
						if(is_array($mods)) {
							$mods = array_reverse($mods);
							foreach($mods as $key => $value) {
								if($value["mod_rname"] == $last) { 
									continue;
								}
								$last = $value["mod_rname"];
					?>			
						<div class="col-12 mb-4">
							<div class="card border-0 shadow">
								<div class="card-header itemcardnew store_hoverhide" onclick="showhide_store($(this));">
									<div class="row align-items-center">
										<div class="col" style="font-size: 13px;"> 
											<h2 class="fs-6 fw-bold mb-0"><?php echo htmlspecialchars($value["mod_name"] ?? ''); ?></h2>
											<small class="text-info">Identification ID: <?php echo $value["mod_rname"]; ?></small><br />
											<?php if($value["mod_type"] == 2) { echo '<span class="badge bg-primary">Script</span>'; } elseif($value["mod_type"] == 3) { echo '<span class="badge bg-secondary">Extension</span>'; } elseif($value["mod_type"] == 5) { echo '<span class="badge bg-purple">Docker</span>'; } elseif($value["mod_type"] == 4) { echo '<span class="badge bg-info">Image</span>'; } elseif($value["mod_type"] == 1) { echo '<span class="badge bg-danger">Website</span>'; } ?>
											<?php echo htmlspecialchars($value["mod_short"] ?? ''); ?>
										</div>
									</div>
								</div>
								<div class="card-body store_autohide">
									<?php if($value["mod_type"] == 3) { ?>  
										<div class="alert alert-warning"><small>This is an extension! You need the website module with the Identification ID: "<?php echo $value["mod_parent_rname"]; ?>" to deploy and use this extension.</small></div>
									<?php } ?>
									<?php if(file_exists("./_store/_module/_image/".$value["mod_rname"]."-".$value["mod_version"].".jpg")) { ?><div style="float: left;padding: 15px; max-width: 100%; width: 200px;padding-top: 0px; padding-left: 0px;">
										<img src="./_store/_module/_image/<?php echo $value["mod_rname"]."-".$value["mod_version"]; ?>.jpg">
									</div> <?php } ?>
									<div class="fs-6" style="font-size: 13px !important;">
										<?php echo htmlspecialchars($value["mod_description"] ?? '');?>
									</div><br clear="both">
									<div class="">
										<table style="font-size: 13px;">
										<tr><td><b>Extension Type</b> </td><td> <?php if($value["mod_type"] == 2) { echo '<span class="badge bg-primary">Script</span>'; } elseif($value["mod_type"] == 3) { echo '<span class="badge bg-secondary">Extension</span>'; } elseif($value["mod_type"] == 5) { echo '<span class="badge bg-purple">Docker</span>'; } elseif($value["mod_type"] == 4) { echo '<span class="badge bg-info">Image</span>'; } elseif($value["mod_type"] == 1) { echo '<span class="badge bg-danger">Website</span>'; } ?></td></tr>
										<tr><td><b>Languages</b> </td><td> 
											<?php
												if($newlang = unserialize($value["mod_lang"])) {
													foreach($newlang AS $keyy => $valuey) {
														echo "<img style='max-width: 30px;' src='./_core/_vendor/country-flags-icons/png/".$valuey.".png'> ";
													}
												} else {
													echo "Unkown";
												}
											?>
										
										</td></tr>
										<tr><td><b>License</b> </td><td><?php echo htmlspecialchars($value["mod_license"] ?? '');?></td></tr>
										<tr><td><b>Autor</b> </td><td> <?php echo htmlspecialchars($value["mod_autor"] ?? ''); ?> 
										[<?php echo htmlspecialchars($value["mod_mail"] ?? ''); ?>]</td></tr>
										<tr><td><b>Website</b> </td><td> <?php echo htmlspecialchars($value["mod_website"] ?? ''); ?><br /><br /></td></tr>
										</table>
										<table style="width: 100%;">
											<?php
												foreach($mods as $keyx => $valuex) {
													if($value["mod_rname"] != $valuex["mod_rname"] /*OR ($valuex["mod_version"] == $value["mod_version"] AND $valuex["mod_build"] == $value["mod_build"]) */) { continue; }
													?>
														<tr>
															<td style="min-width: 100px; max-width: 100%; width: 100%;"><hr> <b>Version</b>: <?php echo $valuex["mod_version"]; ?><br /><br />
															<span style="font-size:13px;"><?php if(file_exists($object["path"]."/_store/_module/_changelog/".$valuex["mod_rname"]."-".$valuex["mod_version"].".html")) { require_once($object["path"]."/_store/_module/_changelog/".$valuex["mod_rname"]."-".$valuex["mod_version"].".html"); } else { echo "Not available"; } ?></span>
															<br /><br />
															<a class="btn btn-primary" href="./_store/_module/_release/<?php echo $valuex["mod_rname"]."-".$valuex["mod_version"].".zip"; ?>">Download</a>
															</td>
														</tr>
													<?php
												}
											?>
										</table>
									</div>
								</div>
							</div>
						</div>
						<?php
								}
							} else { 
						?>			
							<div class="col-12 mb-4">
								<div class="card border-0 shadow">
									<div class="card-header">
										<div class="row align-items-center">
											<div class="col">
												<h2 class="fs-5 fw-bold mb-0">Currently no items available!</h2>
												There are currently no store items available, please come back later!
											</div>
										</div>
									</div>
									<div class="table-responsive">

									</div>
								</div>
							</div>
						<?php
							}
						?>		
						<style>
							.itemcardnew {
								border-bottom-left-radius: 5px;
								border-bottom-right-radius: 5px;
							}
							.store_act {
								background: #1F2937 !important;
								color: white !important;
								cursor: pointer;
								border-bottom-left-radius: 0px;
								border-bottom-right-radius: 0px;
							}
							.store_act h2 {
								color: white !important;
							}
							.store_hoverhide:hover {
								background: #1F2937 !important;
								border-bottom-left-radius: 5px;
								border-bottom-right-radius: 5px;
								color: white !important;
								cursor: pointer;
							}
							
							.store_hoverhide:hover h2 {
								background: #1F2937 !important;
								color: white !important;
							}
							
							.store_act.store_hoverhide:hover {
								border-bottom-left-radius: 0px;
								border-bottom-right-radius: 0px;
							}
						</style>
						<script>
							$(".store_autohide").hide();
							function showhide_store(thisvar) {
								thisvar.addClass('store_clicked');
								thisvar.next().toggle();
								$(".store_hoverhide").each(function() {
									if($(this).hasClass('store_clicked')) { return true; }
									$(this).next().hide();
									$(this).removeClass('store_act');
								});				
								thisvar.removeClass('store_clicked');				
								
								if(thisvar.hasClass('store_act')) { 
									thisvar.removeClass('store_act');
								} else {
									thisvar.addClass('store_act');
								}
							}
						</script>
					</div>
                </div>
            </div>	