<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); }
	switch(_HIVE_URL_CUR_[0]) {
		case false: case "":
			Header("Location: ./?"._HIVE_URL_GET_[0]."=store");
			break;
	}
	x_cookieBanner_Pre(_HIVE_SITE_COOKIE_);
	switch(_HIVE_URL_CUR_[0]) {
		case "hub":
				hive__volt_header($object, "bugfishHUB", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="start, info, homepage, info, bugfish, windows, software"><meta property="og:type" content="website"> <meta property="og:description" content="Get the latest version of the bugfishHUB windows software!"><meta property="og:title" content="bugfishHUB'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta name="description" content="Get the latest version of the bugfishHUB windows software!">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/hub.php");
		break;	
		case "store":
			$structdata = '<script type="application/ld+json">{"@context": "http://schema.org","@type": "ItemList","itemListElement": [';
			$mods = $object["mysql"]->select("SELECT * FROM "._TABLE_HUB_." ORDER BY mod_rname, mod_version DESC", true);
			$last = false;
			if(is_array($mods)) {		
				$mods = array_reverse($mods);
				foreach($mods as $key => $value) {
					if($value["mod_rname"] == $last) { 
						continue;
					}		
					$last = $value["mod_rname"];			
					$structdata .= '{"@type": "ListItem","position": '.$key.',"item": {"@type": "Product","name": "'.htmlspecialchars($value["mod_name"], ENT_QUOTES, 'UTF-8').'","description": "'.htmlspecialchars($value["mod_short"], ENT_QUOTES, 'UTF-8').'","brand": {"@type": "Brand","name": "'.htmlspecialchars($value["mod_autor"], ENT_QUOTES, 'UTF-8').'","image": "./_core/_image/image.cms_logo.jpg"},"offers": {"@type": "Offer","price": "0.00","priceCurrency": "USD","availability": "http://schema.org/InStock"}, "image": "./_store/_hub/_download/_image/'.$value["mod_rname"]."-".$value["mod_version"].'.jpg", "shippingDetails": {"@type": "ShippingDeliveryTime","shippingPolicy": "No shipping required for downloadable products"},"warranty": "No warranty provided in any way.","legalDisclaimer": "No liability for damages or data loss associated with the use of this product.","hasMerchantReturnPolicy": {"@type": "MerchantReturnPolicy","refundType": "NoRefunds","returnPolicyCategory": "Software"},"review": [],"priceValidUntil": "2077-12-31","aggregateRating": {"@type": "AggregateRating","ratingValue": "5","reviewCount": "1"}}},';
				}
				$structdata = substr($structdata, 0, -1);
			}				
			$structdata .= "]}</script>";
				hive__volt_header($object, "Software Store", $structdata.'<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="store, extensions, modules, bugfish, windows, software"><meta property="og:type" content="website"><meta name="description" content="Explore and download windows software by bugfish, this software can also be obtained using our bugfishHUB Software."><meta property="og:description" content="Explore and download windows software by bugfish, this software can also be obtained using our bugfishHUB Software."><meta property="og:title" content="Software Store'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/store.php");
		break;			
		case "app":
				hive__volt_header($object, "bugfishAPP", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="bugfishapp, android, download, bugfish, app"><meta property="og:type" content="website"> <meta property="og:description" content="On this page you can get the latest version of the bugfishAPP Android App!"><meta property="og:title" content="bugfishAPP'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta name="description" content="On this page you can get the latest version of the bugfishAPP Android App!">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/app.php");
		break;
		case "support":
				hive__volt_header($object, "Support", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="support, help, bugfish, software"><meta property="og:type" content="website"><meta property="og:description" content="Get help and support for our products and services. Contact our support team for assistance."><meta property="og:title" content="Support'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta name="description" content="Get help and support for our products and services. Contact our support team for assistance.">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/support.php");
		break;			
		case "documentation":
				hive__volt_header($object, "Documentation", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="documentation, help, bugfish, software"><meta property="og:type" content="website"><meta name="description" content="Access comprehensive guides and documentation for using our product."><meta property="og:description" content="Access comprehensive guides and documentation for using our product."><meta property="og:title" content="Documentation'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/documentation.php");
		break;			
		case "privacy":
				hive__volt_header($object, "Privacy", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="privacy, bugfish, software"><meta property="og:type" content="website"><meta name="description" content="Read our privacy policy to understand how we handle your personal data and protect your privacy."><meta property="og:title" content="Privacy'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta property="og:description" content="Read our privacy policy to understand how we handle your personal data and protect your privacy.">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/privacy.php");
		break;				
		case "license":
				hive__volt_header($object, "License", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="license, gpl, bugfish, software"><meta name="description" content="Information about the projects license!"><meta property="og:description" content="Information about the projects license!"><meta property="og:title" content="License'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta property="og:type" content="website">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/license.php");
		break;		
		case "impressum":
				hive__volt_header($object, "Imprint", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="index, follow"><meta name="keywords" content="imprint, owner, bugfish, software"><meta name="description" content="Find legal information and contact details in our Impressum."><meta property="og:description" content="Find legal information and contact details in our Imprint."><meta property="og:title" content="Imprint'._HIVE_TITLE_SPACER_._HIVE_TITLE_.'"><meta property="og:type" content="website">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				require_once(_HIVE_PATH_."/_site/"._HIVE_MODE_."/impressum.php");
		break;	
		default:
				hive__volt_header($object, "Error 404", '<meta property="og:image" content="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/logo.jpg"><link rel="icon" type="image/x-icon" href="'._HIVE_URL_REL_.'/_site/'._HIVE_MODE_.'/_theme/favicon.ico"><meta name="robots" content="noindex, nofollow">', "dark");
				hive__volt_nav($object, _HIVE_TITLE_, false);
				hive__volt_topbar($object, false,  false, false, false, false, false, false);
				echo "<br />"; hive__volt_404($object, "Error 404", "Page not found!");	
	}	
	
	$object["eventbox"]->show("Close");
	x_cookieBanner(_HIVE_SITE_COOKIE_, true);
	hive__volt_footer($object, _STORE_FOOTER_);
