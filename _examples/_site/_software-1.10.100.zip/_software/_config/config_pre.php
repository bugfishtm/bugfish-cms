<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	 if(!is_array($object)) { http_response_code(404); Header("Location: ../"); exit(); }
	#####################################################################################
	## Website Settings
	#####################################################################################
		# Title Spacer for Tabs in Browser
		define('_HIVE_TITLE_SPACER_',  			" - "); 
		
	#####################################################################################
	## URL Navigation Settings
	#####################################################################################
		# Only neeed if _HIVE_URL_SEO_ == false [Name for Get Location Variables]
		define('_HIVE_URL_GET_', 				array("l1", "l2", "l3", false, false)); 
		#_HIVE_URL_CUR_ Contains current url elements
		#_HIVE_URL_REL_ Relative Folder Path
		
	#####################################################################################
	## Language Settings
	#####################################################################################
		define("_HIVE_LANG_DEFAULT_", 			"en"); # Array with Default Language
		define("_HIVE_LANG_ARRAY_", 			array("en")); # Array with valid Languages
		
	#####################################################################################
	## Theme/Color Settings
	#####################################################################################
		define("_HIVE_THEME_DEFAULT_", 			"dynamic"); # Default Used Theme
		define("_HIVE_THEME_ARRAY_", 			array("dynamic")); # Array with valid Themes
		define("_HIVE_THEME_COLOR_DEFAULT_", 	"#07b8ff"); # Default Color for Dynamic Theme Colors
		#_HIVE_THEME_ Contains current choosen theme
		#_HIVE_COLOR_ Contains current choosen theme
		
