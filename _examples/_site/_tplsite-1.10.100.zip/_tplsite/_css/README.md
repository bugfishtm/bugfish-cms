# CSS Loadup Folder

## Overview
The `_css` folder is designated for storing CSS files that are automatically loaded into BugfishCMS via the HTML include at `/core/stylesheet.php`. This folder helps manage CSS code required for various styling needs depending on the user's login status.

The typical files you might find in this folder include:
- **CSS Files**: Containing styles relevant to the CMS functionalities.
- **PHP Files**: These can also be used to include PHP code, with settings and initializations already handled at file load-up.


## Auto-Loading Stylesheets
CSS files in this folder are auto-loaded based on specific naming conventions:

- **`css.global.*`**: These files are included for both logged-in and non-logged-in users.
- **`css.restricted.*`**: These files are included only when the user is logged in.
- **`css.public.*`**: These files are included only when the user is not logged in.

## Available Variables
Variables initialized from Site Module are available, also if this css file is an extrension for this site module you will get the following info:

|Variable|Description|
|-----|-----|
|$object["extension"]["info"]| Current Extension version.php Array |
|$object["extension"]["path"]| Current Extension Folder Path |
|$object["extension"]["name"]| Current Extension Name |
|$object["extension"]["prefix"]| Current Extension Table Prefix |
|$object["extension"]["cookie"]| Current Extension Cookie Prefix |

Happy Coding!  
Bugfish <3

