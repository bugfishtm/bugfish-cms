# Site Builder Library

In this folder you can store Site Builder Functionalities if your website is using that functionality imported out of the _administrator module. New Functionalities for the builders can be deployed here!

Happy Coding!  
Bugfish <3