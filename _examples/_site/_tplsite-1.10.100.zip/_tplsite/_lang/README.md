# Language File Folder

This folder contains automatically loaded language files. These files belong to the current loaded Site Module. You can override Translation Keys by puttin them into the database for translations, so users can edit them onsite if you give them this possibility.

Name files in this folder like: LANGUAGEKEY.php . LANGUAGEKEY is the string you define for the language in the available language array for your site module. See example or administrator Site Module for examples.

Happy Coding!  
Bugfish <3