# Theme Files

## Overview
This folder is dedicated to storing files related to the users' templates. These files are essential for defining the appearance and structure of the user interface in BugfishCMS.

## Folder Contents
The typical files you might find in this folder include:
- **HTML Files**: These files define the layout of the user interface.
- **CSS Files**: These files contain the styling rules for the user interface.
- **JavaScript Files**: These scripts provide dynamic behaviors for the user interface.

Happy Coding!  
Bugfish <3