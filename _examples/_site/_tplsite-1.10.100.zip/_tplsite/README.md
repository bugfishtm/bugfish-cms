# 🌐 bugfishCMS Site Module

## 🧩 **General Information**

Site modules can run as standalone websites or alongside other installed website modules. They can be distributed across various domains and virtual hosts, offering full control over administration needs.

- **Naming Conventions**: Module names (`RNAME`) must start with a lowercase letter (a-z) and contain a maximum of 10 characters.
- **Extendibility**: Site modules can be extended using script or extension modules.

For detailed guidance, refer to our example Site Module in the [Github repository](#).

## 🗂️ **Folder Structure**

Organize your site module ZIP file as follows. Replace `RNAME` with your module name.

### _admin
See inside folders readme.md for more information.

```
./RNAME/_admin/
├── mod_setting.php (Module settings script)
```

### _config
See inside folders readme.md for more information.

```
./RNAME/_config/
├── config_pre.php (Pre-startup configuration)
├── config_post.php (Post-startup configuration)
├── global_pre.php (Global pre-startup configuration)
├── global_post.php (Global post-startup configuration)
├── global.php (Global configuration file)
└── config.php (Main configuration file)
```

### _cron
Store your Code for cronjobs in this folder. See example files in our example site module _tplsite which you can obtain in our official store at store.bugfish.eu!

```
./RNAME/
├── _cron/
│   ├── _daily/* (Daily cronjob injection scripts)
│   ├── _hourly/* (Hourly cronjob injection scripts)
│   ├── _weekly/* (Weekly cronjob injection scripts)
│   ├── _yearly/* (Yearly cronjob injection scripts)
│   └── _monthly/* (Monthly cronjob injection scripts)
```

### _css
See inside folders readme.md for more information.

```
./RNAME/_css/ (Add CSS files here)
```

### _js
See inside folders readme.md for more information.

```
./RNAME/_js/ (Add JS files here)
```

### _lang
See inside folders readme.md for more information.

```
./RNAME/_lang/ (Add language files here)
```

### _lib
See inside folders readme.md for more information.

```
./RNAME/_lib/ (Add library files here)
```

### _mysql
See inside folders readme.md for more information.

```
./RNAME/_mysql/ (Add SQL files here for auto-installation)
```

### _theme
See inside folders readme.md for more information.

```
./RNAME/_theme/ (Add theme files here)
```

### _update
See inside folders readme.md for more information.

```
./RNAME/_update/ (Add update files here)
```

### _wfc
See inside folders readme.md for more information.

```
./RNAME/_wfc/ (Add site widgets here)
```

### Files

```
./RNAME/
├── load.php (Site loadup file)
├── version.php (Versioning info)
├── changelog.php (Changelog info)
└── preview.jpg (Preview image)
```

Happy Coding!  
Bugfish <3














