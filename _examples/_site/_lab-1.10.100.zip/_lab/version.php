<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
		
		File Description:
			Versioning File to Contain Module Information!
	*/	
	$x = array();
		
	##############################
	// Module Various Informations
	##############################
	
		// Module Unique ID
		// Unique Module Identifier (should NEVER be the same on 2 different modules)
		// You can ask at requests@bugfish.eu for your unique module identifiert to provide 
		// Modules to an official online store.
		// Do not use special chars, no more than 10 signs for rname of this module type!
		$x["rname"] 		= "_lab";
		
		// Module Language
		// Available Languages in this Module Array (shortcodes)
		$x["lang"] 			= array("en");
		
		// Database Build Information.
		// This Number will be used for updater script
		// to determine if update is needed and build number is stored
		// for active site module in database together with rname
		$x["build"] 		= "100";
		
		// Version Number, only imaginary (has to end with build number)
		$x["version"] 		= "1.10.".$x["build"];
		
		// Module Title and Name
		$x["name"] 			= "Redirect: Token Switches";
		
		// Short Description
		$x["short"] 		= "Just a simple module which redirects to the token switch form. For easy use for developers on a dedicated standalone page with no overrides to test different pages. We were/are using this script on lab.bugfish.eu!";
		
		// Module Full Description 
		$x["description"] 	= "We need a straightforward module that provides a seamless redirection to the token switch form, designed specifically for developers. This module should be deployed on a dedicated standalone page, ensuring no overrides or conflicts with other scripts or styles. The purpose is to enable developers to easily test and switch between different site modules across various pages with tokens. We’ve previously implemented a similar script on lab.bugfish.eu, which has proven useful, and we're looking to replicate or improve that functionality for consistent, hassle-free testing.";
		
		// Module Type
		// 1 - Site Module
		// 2 - Public Application Modul
		// 3 - Extension for RNAME
		// 4 - Image Module
		// 5 - Docker Image Module
		$x["type"] 			= 1;
		
		// Parent Module
		// If this Extension/Module is related to a Parent Extension/Module enter the Parent rname below!
		// This can be an array("mod", "mod") or string for a single module
		$x["parent_rname"] 	= false;

		// Single Instance Module?
		// If true, than this modules rname can only be deployed a single time on that cms instance.
		// Recommended for Server Software where duplications of the module activated may lead to issues.
		// Module will be forced to use RNAME as Site Module Name
		$x["single_instance"] 	= false;			
		
	##############################
	// Module Autor Informations
	##############################
	
		// Module License (gplv3, gplv2, mit, bsd, bsd2, ...)
		$x["license"] 		= "gplv3";
		
		// Module Autor Name
		$x["autor"] 		= "Bugfish";
		
		// Module Autor Mail
		$x["mail"] 			= "requests@bugfish.eu";
		
		// Module Autor Website
		$x["website"] 		= "www.bugfish.eu";
