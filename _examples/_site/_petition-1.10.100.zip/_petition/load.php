<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); }?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="robots" content="index, follow">
    <meta name="author" content="Jan-Maurice Dahlmanns">
	
	<!-- Meta Info -->
	<title>Petition für Sonderstaatsanwaltschaften gegen Polizeigewalt</title>
	<meta property="og:title" content="Petition für Sonderstaatsanwaltschaften gegen Polizeigewalt">
	<meta property="og:image" content="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/about.jpg"> 
	<meta property="og:description" content="Unterstützen Sie unsere Petition für unabhängige Sonderstaatsanwaltschaften gegen Polizeigewalt in Deutschland. Setzen Sie sich für Transparenz, Gerechtigkeit und den Schutz der Bürgerrechte ein.">
	<meta name="description" content="Unterstützen Sie unsere Petition für unabhängige Sonderstaatsanwaltschaften gegen Polizeigewalt in Deutschland. Setzen Sie sich für Transparenz, Gerechtigkeit und den Schutz der Bürgerrechte ein.">
	<meta property="og:type" content="website">
	<meta name="keywords" content="polizeigewalt, polizei, petition, ermittlungen, bugfish">
	
	
	
	<!-- Struct Data -->
	<script type="application/ld+json">
	{
	  "@context": "https://schema.org",
	  "@type": "WebPage",
	  "name": "Petition für Sonderstaatsanwaltschaften gegen Polizeigewalt",
	  "description": "Unterstützen Sie unsere Petition für unabhängige Sonderstaatsanwaltschaften gegen Polizeigewalt in Deutschland. Setzen Sie sich für Transparenz, Gerechtigkeit und den Schutz der Bürgerrechte ein.",
	  "url": "https://www.example.com",
	  "image": {
		"@type": "ImageObject",
		"url": "<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/about.jpg",
		"width": 1200,
		"height": 630
	  },
	  "keywords": "polizeigewalt, polizei, petition, ermittlungen, bugfish",
	  "publisher": {
		"@type": "Organization",
		"name": "Bugfish",
		"logo": {
		  "@type": "ImageObject",
		  "url": "<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/logo.png"
		}
	  }
	}
	</script>
		
	<!-- Favicon icons -->
	<link rel="icon" href="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/favicon.ico" type="image/x-icon">
	
    <!-- font icons -->
    <link rel="stylesheet" href="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/vendors/themify-icons/css/themify-icons.css">

    <!-- Bootstrap + Creative Studio main styles -->
	<link rel="stylesheet" href="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/css/creative-studio.css">
	
	<!-- Style Changes -->
	<style>
		a {
			color: #036ffc !important;
		}
		
		.custom-navbar .nav-link.active {
			color: #036ffc !important;
		}
		
		.btn-primary {
			background: #036ffc;
			border: none;
			color: white !important;
		}
	
	</style>

</head>
<body data-spy="scroll" data-target=".navbar" data-offset="40" id="home">
    
    <!-- Page Navigation -->
    <nav class="navbar custom-navbar navbar-expand-lg navbar-dark" data-spy="affix" data-offset-top="20">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/logo.png" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#home">Start</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">Informationen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#service">Argumente</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#testimonial">Kommentare</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://bugfishtm.blogspot.com/2023/05/impressum.html" rel="noopener" target="_blank">Impressum</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://bugfishtm.blogspot.com/2023/05/privacy.html" rel="noopener" target="_blank">Datenschutz</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- End Of Page Navigation -->

    <!-- Page Header -->
    <header class="header">
        <div class="overlay">
            <h6 class="subtitle py-2 px-2">Wir fordern Unabhängige Sonderstaatsanwaltschaften für </h6>
            <h1 class="title">Polizeivergehen</h1>
            <div class="buttons text-center">
                <a href="https://www.openpetition.de/petition/online/unabhaengige-ermittlungsstelle-fuer-polizeivergehen" rel="noopener" target="_blank" class="btn btn-primary rounded w-lg btn-lg my-1">Mach mit</a>
            </div>              
        </div>      
    </header>
    <!-- End Of Page Header -->
	
    <!-- About Section -->
    <section id="about">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-5 col-lg-4">
                    <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/about.jpg" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page" class="w-100 img-thumbnail mb-3">
                </div>
                <div class="col-md-7 col-lg-8">
                    <h6 class="section-subtitle mb-0">Informationen</h6>
                    <h6 class="section-title mb-3">Über die Petition</h6>
					
					<p>Diese Petition fordert die Einrichtung von Sonderstaatsanwaltschaften mit spezialisierten Ermittlern zur Untersuchung von Polizeigewalt, Korruption und schwerwiegendem Fehlverhalten in Deutschland. In anderen Ländern, wie Schweden, Großbritannien und Kanada, haben unabhängige Ermittlungsbehörden maßgeblich dazu beigetragen, Fälle von polizeilichem Fehlverhalten fair und objektiv zu prüfen. Auch in Deutschland sollen diese Sonderstaatsanwaltschaften völlig unabhängig von der Polizei agieren, um sicherzustellen, dass alle Ermittlungen unparteiisch, transparent und professionell durchgeführt werden.</p>

					<b>Aufbau einer Sonderstaatsanwaltschaft</b>
					<p>Diese spezialisierten Ermittlungsstellen sollen sowohl auf Bundes- als auch auf Landesebene eingerichtet werden, um eine flächendeckende und gerechte Aufklärung von Fällen zu ermöglichen.</p>
						
					<b>Struktur und Zuständigkeit einer Sonderstaatsanwaltschaft</b>
					<p>Eine deutsche Sonderstaatsanwaltschaft für Polizeigewalt könnte ähnlich wie in Schweden als eine unabhängige Einheit innerhalb der Justiz agieren. Sie sollte folgende Merkmale aufweisen:</p>
					<p>Unabhängige Ermittler: Ausgestattet mit Ermittlern, die speziell für die Untersuchung von polizeilichem Fehlverhalten geschult sind und außerhalb der Polizeistrukturen arbeiten.<br /> - Koordination mit anderen Behörden: Zusammenarbeit mit Gerichten, Menschenrechtsorganisationen, und unabhängigen Sachverständigen.</p>

					<b>Beteiligte Akteure einer Sonderstaatsanwaltschaft</b>
					<p>- Bundesregierung und Landesregierungen: Schaffung der rechtlichen Rahmenbedingungen und Anpassungen im Strafverfahrensrecht.<br/> - Bundes- und Landesjustizministerien: Einrichtung und Finanzierung der Sonderstaatsanwaltschaft.<br/> - Bundes- und Landesparlamente: Verabschiedung entsprechender Gesetzesvorlagen.<br/> - Ombudsstellen oder Bürgerbeauftragte: Vermittler zwischen Bevölkerung und Sonderstaatsanwaltschaft.</p>

					<b>Funktionsweise einer Sonderstaatsanwaltschaft</b>
					<p> - Transparente Verfahren: Anzeigen gegen Polizeibeamte werden automatisch an die Sonderstaatsanwaltschaft weitergeleitet.
					<br /> - Spezialisierte Untersuchungsteams: Bestehend aus Ermittlern, forensischen Experten und Anwälten.
					<br /> - Unabhängige Beweiserhebung: Direkte Sammlung aller Beweise und Zeugenaussagen durch die Sonderstaatsanwaltschaft.
					<br /> - Regelmäßige Berichterstattung: Veröffentlichung von Berichten über laufende und abgeschlossene Ermittlungen.</p>

					<b>Anpassungen im Strafrecht für eine Sonderstaatsanwaltschaft</b>
					<p class="mb-0 pb-0 m-b-0 p-b-0">Es müsste im Strafgesetzbuch (StGB) und im Gesetz über die Strafverfolgung (StPO) verankert werden, dass Vorwürfe gegen Polizeibeamte hinsichtlich Gewaltanwendung und schwerem Fehlverhalten ausschließlich von der Sonderstaatsanwaltschaft untersucht werden. Weitere Regelungen zur Beschleunigung der Verfahren und Sicherstellung von Transparenz und Unabhängigkeit wären erforderlich.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- End of About Section -->

    <!-- Service Section -->
    <section id="service">
        <div class="container">
            <h6 class="section-subtitle text-center">Pro-Argumente</h6>
            <h5 class="section-title text-center mb-6">Für unabhängige Ermittlungen</h5> 
            <div class="row">
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Transparenz und Rechenschaftspflicht</h6>
                            <p>Die unabhängige Ermittlung ermöglicht eine transparente Aufklärung von Vorwürfen, was nicht nur die Verantwortlichkeit der Polizei fördert, sondern auch der Öffentlichkeit Einblick in den Umgang mit Polizeigewalt gibt. Dies trägt zur Schaffung eines Vertrauensverhältnisses zwischen der Polizei und der Bevölkerung bei.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Schutz vor Ungerechtigkeit</h6>
                            <p>Eine unabhängige Ermittlungsbehörde würde sicherstellen, dass sowohl Bürger als auch ehrliche Polizeibeamte vor ungerechtfertigten Anschuldigungen und Verleumdungen geschützt werden. Dies könnte dazu führen, dass Vorwürfe schneller und effizienter entkräftet werden.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Prävention von Fehlverhalten</h6>
                            <p>Die Existenz einer Sonderstaatsanwaltschaft könnte als abschreckende Maßnahme für potenzielles Fehlverhalten unter Polizeibeamten wirken. Das Wissen, dass Vorwürfe unabhängig untersucht werden, könnte dazu führen, dass Beamte sich verantwortungsbewusster verhalten.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Bessere Datenlage und Forschung</h6>
                            <p>Die unabhängige Erfassung und Analyse von Fällen von Polizeigewalt kann wertvolle Daten liefern, die zur Verbesserung von Ausbildungsprogrammen und zur Entwicklung von Richtlinien innerhalb der Polizei beitragen können. Eine evidenzbasierte Politik ist entscheidend für langfristige Verbesserungen.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Internationale Vorbildfunktion</h6>
                            <p>Die Schaffung einer solchen Institution könnte Deutschland als Vorbild für andere Länder positionieren, die mit ähnlichen Herausforderungen im Bereich der Polizeigewalt konfrontiert sind. Dies würde nicht nur die internationale Reputation stärken, sondern auch den Austausch bewährter Praktiken fördern.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Verstärkung des Rechtsstaatsprinzips</h6>
                            <p>Eine unabhängige Ermittlungsstelle für Polizeigewalt würde die grundlegenden Prinzipien des Rechtsstaats fördern, indem sie sicherstellt, dass niemand über dem Gesetz steht und alle Bürger gleich behandelt werden, unabhängig von ihrem Status oder Beruf.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Besserer Zugang zu Gerechtigkeit</h6>
                            <p>Bürger, die Opfer von Polizeigewalt werden, hätten durch die unabhängige Ermittlungsbehörde einen leichteren Zugang zu Gerechtigkeit und könnten sicher sein, dass ihre Anliegen ernst genommen werden. Dies könnte zu einer höheren Bereitschaft führen, Vorfälle zu melden und Vertrauen in das Justizsystem zu setzen.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Unabhängigkeit und Objektivität</h6>
                            <p>Eine unabhängige Behörde wäre völlig losgelöst von polizeilichen Strukturen und könnte daher objektive, faire und transparente Ermittlungen durchführen. So wird sichergestellt, dass Fälle von Polizeigewalt unvoreingenommen untersucht werden.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Vertrauensstärkung</h6>
                            <p>Durch die Schaffung einer unabhängigen Ermittlungsstelle kann das Vertrauen der Bürger in die Polizei und den Rechtsstaat gestärkt werden. In Ländern wie Schweden und Großbritannien hat sich gezeigt, dass eine solche Einrichtung hilft, das Verhältnis zwischen Polizei und Bevölkerung zu verbessern.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h6 class="card-title">Schutz für Polizeibeamte</h6>
                            <p>Beamte, die sich korrekt und rechtmäßig verhalten, profitieren von der unabhängigen Stelle, da Vorwürfe schnell und objektiv entkräftet werden können. Dies schützt ehrliche Polizisten vor ungerechtfertigten Verdächtigungen.</p>
                        </div>
                    </div>
                </div>
            </div>  
        </div>
    </section>
    <!-- End of Service Section -->


    <!-- Testimonial Section -->
    <section id="testimonial">
        <div class="container">
            <h6 class="section-subtitle text-center">Kommentare</h6>
            <h6 class="section-title text-center mb-6">Von Betroffenen</h6>
            <div class="row">
                <div class="col-md-6">
                    <div class="testimonial-wrapper" style="width: 100%;">
                        <div class="img-holder">
                            <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/acc.png" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page">                     
                        </div>
                        <div class="body" style="width: 100%;">
                            <p class="subtitle">Nach einer Hausdurchsuchung mit Inhaftierung ist mein Haustier verschwunden, auf Anfrage sagte die örtliche Polizei, Sie hätte "Meine Katze gefressen".</p>
                            <h6 class="title">[Geheim]</h6>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="testimonial-wrapper" style="width: 100%;">
                        <div class="img-holder">
                            <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/acc.png" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page">                     
                        </div>
                        <div class="body" style="width: 100%;">
                            <p class="subtitle">Ich wurde bedroht und beleidigt, weil ich trotz ärtztlichem Atest an einem öffentlichen aber abgelegenem Ort Cannabis geraucht habe.</p>
                            <h6 class="title">[Geheim]</h6>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="testimonial-wrapper" style="width: 100%;">
                        <div class="img-holder">
                            <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/acc.png" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page">                     
                        </div>
                        <div class="body" style="width: 100%;">
                            <p class="subtitle">Ein Familienmitglied wurde von Polizisten gedemütigt, als er diese wegen Fehlverhalten anzeigte. Auf dem Rückweg von der Arbeit nach Hause wurde er täglich angehalten.</p>
                            <h6 class="title">[Geheim]</h6>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="testimonial-wrapper" style="width: 100%;">
                        <div class="img-holder">
                            <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/acc.png" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page">                     
                        </div>
                        <div class="body" style="width: 100%;">
                            <p class="subtitle">Ich bin selbst betroffen und mein Leben hat sich durch Polizeiliches Fehlverhalten massiv verändert.</p>
                            <h6 class="title">[Geheim]</h6>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="testimonial-wrapper" style="width: 100%;">
                        <div class="img-holder">
                            <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/acc.png" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page">                     
                        </div>
                        <div class="body" style="width: 100%;">
                            <p class="subtitle">ja und das sofort.</p>
                            <h6 class="title">[Geheim]</h6>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="testimonial-wrapper" style="width: 100%;">
                        <div class="img-holder">
                            <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/acc.png" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page">                     
                        </div>
                        <div class="body" style="width: 100%;">
                            <p class="subtitle">Gerade im öffentlichen Dienst ist Transparenz gefragt.</p>
                            <h6 class="title">[Geheim]</h6>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="testimonial-wrapper" style="width: 100%;">
                        <div class="img-holder">
                            <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/acc.png" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page">                     
                        </div>
                        <div class="body" style="width: 100%;">
                            <p class="subtitle">Bekannte von mir sind betroffen.</p>
                            <h6 class="title">[Geheim]</h6>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="testimonial-wrapper" style="width: 100%;">
                        <div class="img-holder">
                            <img src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/imgs/acc.png" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Creative studio Landing page">                     
                        </div>
                        <div class="body" style="width: 100%;">
                            <p class="subtitle">Wir haben leider zuviel Rassismus bei der Polizei.</p>
                            <h6 class="title">[Geheim]</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End of Testimonial Section -->

    <!-- core  -->
    <script src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/vendors/jquery/jquery-3.4.1.js"></script>
    <script src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/vendors/bootstrap/bootstrap.bundle.js"></script>

    <!-- bootstrap affix -->
    <script src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/vendors/bootstrap/bootstrap.affix.js"></script>

    <!-- Creative Studio js -->
    <script src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/assets/js/creative-studio.js"></script>

</body>
</html>
