<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
		
		File Description:
			Versioning File to Contain Module Information!
	*/	
	$x = array();
	
	////////////////////////////////////////
	// Module Various Informations
	////////////////////////////////////////
		// Unique Module Identifier (should NEVER be the same on 2 different modules)
		// You can ask at requests@bugfish.eu for your unique module identifiert to provide 
		// Modules to an official online store.
		// No more than 10 signs for unique site module identifier and no special signs!
		$x["rname"] 		= "_exampleminimal";
		// Available Languages in this Module Array (shortcodes)
		$x["lang"] 			= array("en");
		// Database Build Information.
		// This Number will be used for updater script
		// to determine if update is needed and build number is stored
		// for active site module in database together with rname
		$x["build"] 		= "100";
		// Version Number, only imaginary (has to end with build number)
		$x["version"] 		= "1.10.".$x["build"];
		// Module Title and Name
		$x["name"] 			= "Example: Minimal Theme";
		// Short Description
		$x["short"] 		= "The _example-minimal module highlights Bugfish CMS's minimal responsive theme, providing a streamlined demonstration of its simplicity and adaptability.";
		// Module Full Description 
		$x["description"] 	= "The _example-minimal module serves as a beacon of simplicity within Bugfish CMS, showcasing the elegance and adaptability of its minimal responsive theme. Explore a clean and intuitive interface, meticulously crafted to prioritize content and user experience. Whether you're a developer seeking inspiration for sleek designs or a website owner aiming for a polished look, the _example-minimal module offers valuable insights into harnessing Bugfish CMS's minimalist aesthetic.";
		// Module Type
		// 1 - Site Module
		// 2 - Public Application Modul
		// 3 - Extension for RNAME
		// 4 - Image Module
		$x["type"] 			= 1;
		// If Module Type is 3 enter Parent RNAME here
		// Otherwhise set to false
		$x["parent_rname"] 	= false;
	
	////////////////////////////////////////
	// Module Autor Informations
	////////////////////////////////////////
		// Module License (gplv3, gplv2, mit, bsd, bsd2, ...)
		$x["license"] 		= "gplv3";
		// Module Autor Name
		$x["autor"] 		= "Bugfish";
		// Module Autor Mail
		$x["mail"] 			= "requests@bugfish.eu";
		// Module Autor Website
		$x["website"] 		= "www.bugfish.eu";