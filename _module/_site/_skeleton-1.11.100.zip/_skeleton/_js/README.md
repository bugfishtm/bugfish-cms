# 📁 _js Folder

## 📄 Overview
The `_js` folder is designated for storing JavaScript files that are automatically loaded into the BugfishCMS via the HTML include at `/core/javascript.php`. This folder helps manage JavaScript code required for various functionalities depending on the user's login status.

## 🔄 Auto-Loading Scripts
JavaScript files in this folder are auto-loaded based on specific naming conventions:

- **`js.global.*`**: These files are included for both logged-in and non-logged-in users.
- **`js.restricted.*`**: These files are included only when the user is logged in.
- **`js.public.*`**: These files are included only when the user is not logged in.

## 📂 Folder Contents
The typical files you might find in this folder include:
- **JavaScript Files**: Containing JS code relevant to the CMS functionalities.
- **PHP Files**: These can also be used to include PHP code, with settings and initializations already handled at file load-up.

## 🛠️ How to Use
1. **Create Your JavaScript Files**:
   - For global scripts: Name them as `js.global.*.js`.
   - For restricted scripts: Name them as `js.restricted.*.js`.
   - For public scripts: Name them as `js.public.*.js`.
2. **Auto-Loading**:
   - Place your files in the `_js` folder and they will be automatically included based on the user's login status.
3. **PHP Integration**:
   - If you need to include PHP code, create `.php` files and place them in this folder. Settings and initializations are already done at file load-up, so you can directly add your PHP logic.

## ⚠️ Important Notes
- **Naming Convention**: Adhere to the specified naming conventions to ensure correct auto-loading of your scripts.
- **Dependency Management**: Ensure that your scripts do not have unresolved dependencies which could cause issues during runtime.

## ❓ Need Help?
For any assistance or further information on how to use and develop scripts in the `_js` folder, please refer to the BugfishCMS documentation or reach out to the support team.

Happy Coding!  
Bugfish <3