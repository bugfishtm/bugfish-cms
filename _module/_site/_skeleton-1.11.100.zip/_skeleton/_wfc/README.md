# 📁 Site Builder Functionalities

## 📄 Overview
In this folder you can store Site Builder Functionalities if your website is using that functionality imported out of the _administrator module.

## ❓ Need Help?
For any assistance or further information on how to use these template files, please refer to the BugfishCMS documentation or reach out to the support team.

Happy Coding!  
Bugfish <3